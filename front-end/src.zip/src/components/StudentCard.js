// import React, { useState } from 'react';
// // import { useNavigate } from 'react-router-dom';
// import { useRouter } from 'next/router';
// // import '../styles/Components.css';

// function StudentCard({ student, isSummaryDefault = false }) {
//   const [isSummary, setIsSummary] = useState(isSummaryDefault);
//   // const navigate = useNavigate();
//   const router = useRouter();

//   const toggleSummary = () => {
//     setIsSummary(!isSummary);
//   };

//   const goToMap = () => {
//     // navigate('/map');
//     router.push('/map');
//   };

//   const { studentName, studentClass, morningTrip, afternoonTrip } = student;
//   const trip = morningTrip; // Dùng thông tin chuyến đi buổi sáng cho cả 2 dạng hiển thị

//   // Chọn trạng thái hiển thị:
//   // Dạng 1: Đầy đủ (trang chính bên trái) - Dùng khi isSummary = false
//   // Dạng 2: Tóm tắt (trang chính bên phải) - Dùng khi isSummary = true

//   return (
//     <div className={`student-card ${isSummary ? 'summary-mode' : 'full-mode'}`}>
//       {/* Phần Header chung */}
//       <div className="student-header">
//         <div className="student-info">
//                     <div>
//             <p className="name">{studentName}</p>
//             <p className="class">{studentClass}</p>
//           </div>
//         </div>
//         <div className={`status-tag status-${trip.status.toLowerCase().replace(/\s/g, '-')}`}>
//           Trạng thái: <strong>{trip.status}</strong>
//         </div>
//       </div>

//       {/* Thông tin chuyến đi & nút */}
//       <div className="trip-info-container">
//         {/* Thông tin chính */}
//         <div className="main-trip-info">
//           {/* Thông tin trạng thái chi tiết */}
//           {!isSummary ? (
//             // Dạng đầy đủ (Full Mode)
//             <div className="full-details">
//               <p className="action-text"> {trip.currentAction}</p>
//               <div className="progress-bar-container">
//                 <div 
//                     className="progress-bar" 
//                     style={{ width: `${trip.progress}%` }}
//                 ></div>
//                 <span>{trip.progress}%</span>
//               </div>
//               <p>Dự kiến đến: <strong>{trip.estimatedArrivalTime}</strong></p>
//             </div>
//           ) : (
//             // Dạng tóm tắt (Summary Mode)
//             <div className="summary-details">
//               <p className="action-text"> {trip.currentAction}</p>
//               <p>Thời gian đến: <strong>{trip.arrivalTime || trip.scheduledTime}</strong></p>
//             </div>
//           )}

//           {/* Nút Xem bản đồ (chung) */}
//           <button className="map-button" onClick={goToMap}>
//              Xem bản đồ
//           </button>
//         </div>
        
//         {/* Thông tin chi tiết chuyến đi (chỉ hiển thị ở Full Mode) */}
//         {!isSummary && (
//           <div className="detailed-trip-info">
//             <p>Chuyến đón:</p>
//             <p>Xe buýt: <strong>{trip.busNumber}</strong></p>
//             <p>Thời gian đón: <strong>{trip.scheduledTime}</strong></p>
//             <p>Tài xế: <strong>{trip.driverName}</strong></p>
//             <p>Điểm đón: <strong>{trip.pickupPoint}</strong></p>

//             <div className="pickup-status">
//                             Trạng thái: <span className={`status-${trip.pickupStatus.toLowerCase().replace(/\s/g, '-')}`}>{trip.pickupStatus}</span>
//             </div>

//             {/* Thông tin chuyến trả (Buổi chiều) */}
//             <div className="afternoon-trip">
//               <p>Chuyến trả:</p>
//               <p>Xe buýt: <strong>{afternoonTrip.busNumber}</strong></p>
//               <p>Thời gian đón: <strong>{afternoonTrip.scheduledTime}</strong></p>
//               <p>Điểm trả: <strong>{afternoonTrip.pickupPoint}</strong></p>
//               <p>Tài xế: <strong>{afternoonTrip.driverName}</strong></p>
              
//               <div className="pickup-status">
//                                 Trạng thái: <span className={`status-${afternoonTrip.status.toLowerCase().replace(/\s/g, '-')}`}>{afternoonTrip.status}</span>
//               </div>
//             </div>
//           </div>
//         )}
//       </div>

//       {/* Nút Ẩn bớt / Chi tiết */}
//       <button className="toggle-button" onClick={toggleSummary}>
//         {isSummary ? ' Chi tiết' : ' Ẩn bớt'}
//       </button>
//     </div>
//   );
// }

// export default StudentCard;
// src/components/StudentCard.js
import React, { useState } from "react";
import { useRouter } from "next/router";

function StudentCard({ student, isSummaryDefault = false }) {
  const [isSummary, setIsSummary] = useState(isSummaryDefault);
  const router = useRouter();

  // Chuyển chế độ hiển thị (tóm tắt / chi tiết)
  const toggleSummary = () => setIsSummary(!isSummary);

  // Chuyển sang trang bản đồ
  const goToMap = () => router.push("/map");

  // Giải nén thông tin học sinh
  const {
    studentName,
    studentClass,
    morningTrip = {},
    afternoonTrip = {},
  } = student;

  // Nếu chưa có dữ liệu, không render
  if (!studentName) return null;

  // Chọn chuyến chính để hiển thị trạng thái
  const mainTrip = morningTrip || {};

  return (
    <div
      className={`student-card ${isSummary ? "summary-mode" : "full-mode"}`}
      style={{
        background: "#fff",
        borderRadius: "12px",
        boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
        padding: "16px",
        transition: "all 0.3s ease",
      }}
    >
      {/* --- Header --- */}
      <div
        className="student-header"
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "10px",
        }}
      >
        <div className="student-info">
          <p
            className="name"
            style={{ fontSize: "1.2rem", fontWeight: "600", margin: 0 }}
          >
            {studentName}
          </p>
          <p
            className="class"
            style={{ fontSize: "0.9rem", color: "#666", margin: 0 }}
          >
            {studentClass}
          </p>
        </div>

        {mainTrip.status && (
          <div
            className={`status-tag status-${mainTrip.status
              .toLowerCase()
              .replace(/\s/g, "-")}`}
            style={{
              fontSize: "0.85rem",
              fontWeight: "500",
              padding: "4px 8px",
              borderRadius: "8px",
              background:
                mainTrip.status.toLowerCase().includes("hoàn thành") ||
                mainTrip.status.toLowerCase().includes("đã đến")
                  ? "#d1f7c4"
                  : "#ffe5b4",
            }}
          >
            Trạng thái: <strong>{mainTrip.status}</strong>
          </div>
        )}
      </div>

      {/* --- Trip info --- */}
      <div className="trip-info-container">
        {!isSummary ? (
          <div className="full-details">
            <p className="action-text" style={{ fontWeight: "500" }}>
              {mainTrip.currentAction || "Đang cập nhật..."}
            </p>

            {/* Thanh tiến trình */}
            {mainTrip.progress !== undefined && (
              <div
                className="progress-bar-container"
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  margin: "8px 0",
                }}
              >
                <div
                  className="progress-bar"
                  style={{
                    height: "6px",
                    background: "#eee",
                    borderRadius: "4px",
                    flex: 1,
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      width: `${mainTrip.progress}%`,
                      height: "6px",
                      background: "#0070f3",
                    }}
                  ></div>
                </div>
                <span style={{ fontSize: "0.85rem" }}>
                  {mainTrip.progress}%
                </span>
              </div>
            )}

            {mainTrip.estimatedArrivalTime && (
              <p>
                Dự kiến đến:{" "}
                <strong>{mainTrip.estimatedArrivalTime}</strong>
              </p>
            )}

            {/* Chi tiết chuyến đi sáng */}
            <div className="trip-detail-section" style={{ marginTop: "10px" }}>
              <p>
                <strong>Chuyến đón:</strong>
              </p>
              <p>Xe buýt: {mainTrip.busNumber}</p>
              <p>Thời gian đón: {mainTrip.scheduledTime}</p>
              <p>Điểm đón: {mainTrip.pickupPoint}</p>
              <p>Tài xế: {mainTrip.driverName}</p>
              {mainTrip.pickupStatus && (
                <p>
                  Trạng thái:{" "}
                  <strong>{mainTrip.pickupStatus}</strong>
                </p>
              )}
            </div>

            {/* Chi tiết chuyến đi chiều */}
            {afternoonTrip && (
              <div
                className="trip-detail-section"
                style={{ marginTop: "10px" }}
              >
                <p>
                  <strong>Chuyến trả:</strong>
                </p>
                <p>Xe buýt: {afternoonTrip.busNumber}</p>
                <p>Thời gian trả: {afternoonTrip.scheduledTime}</p>
                <p>Điểm trả: {afternoonTrip.pickupPoint}</p>
                <p>Tài xế: {afternoonTrip.driverName}</p>
                {afternoonTrip.status && (
                  <p>
                    Trạng thái:{" "}
                    <strong>{afternoonTrip.status}</strong>
                  </p>
                )}
              </div>
            )}
          </div>
        ) : (
          <div className="summary-details">
            <p className="action-text" style={{ fontWeight: "500" }}>
              {mainTrip.currentAction || "Đang cập nhật..."}
            </p>
            <p>
              Thời gian đến:{" "}
              <strong>
                {mainTrip.arrivalTime || mainTrip.scheduledTime || "N/A"}
              </strong>
            </p>
          </div>
        )}
      </div>

      {/* --- Buttons --- */}
      <div
        className="student-actions"
        style={{ display: "flex", justifyContent: "space-between", marginTop: "15px" }}
      >
        <button
          onClick={goToMap}
          className="map-button"
          style={{
            background: "#0070f3",
            color: "#fff",
            border: "none",
            borderRadius: "8px",
            padding: "8px 12px",
            cursor: "pointer",
          }}
        >
          Xem bản đồ
        </button>

        <button
          className="toggle-button"
          onClick={toggleSummary}
          style={{
            background: "#f5f5f5",
            border: "1px solid #ddd",
            borderRadius: "8px",
            padding: "8px 12px",
            cursor: "pointer",
          }}
        >
          {isSummary ? "Chi tiết" : "Ẩn bớt"}
        </button>
      </div>
    </div>
  );
}

export default StudentCard;